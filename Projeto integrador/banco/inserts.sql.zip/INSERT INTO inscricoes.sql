INSERT INTO Inscri��es (nome_participante,especialidade,email,telefone)
VALUES

('Ribamar', 'Ribamar@email.com', 1, '20260601'),
('Vinicius Junior', 'Vinicius@email.com', 2, '20260601'),
('Rodrygo', 'Rodrygo@email.com', 3, '20260602'),
('Raphinha', 'Raphinha@email.com', 4, '20260602'),
('Alisson Becker', 'Alisson@email.com', 5, '20260603'),
('Ederson', 'Ederson@email.com', 6, '20260603'),
('Casemiro', 'Casemiro@email.com', 7, '20260604'),
('Bruno Guimar�es', 'Bruno@email.com', 8, '20260604'),
('Lucas Paquet�', 'Paqueta@email.com', 9, '20260605'),
('Richarlison', 'Richarlison@email.com', 10, '20260605'),
('Marquinhos', 'Marquinhos@email.com', 1, '20260606'),
('Eder Milit�o', 'Militao@email.com', 2, '20260606'),
('Danilo', 'Danilo@email.com', 3, '20260607'),
('Gabriel Magalh�es', 'Gabriel@email.com', 4, '20260607'),
('Endrick', 'Endrick@email.com', 5, '20260608'),
('Estev�o', 'Estevao@email.com', 6, '20260608'),
('Joao Gomes', 'Joao@email.com', 7, '20260609'),
('Pedro Guilherme', 'Pedro@email.com', 8, '20260609'),
('Gerson', 'Gerson@email.com', 9, '20260610'),
('Weverton', 'Weverton@email.com', 10, '20260610');