INSERT INTO Palestrantes (nome,especialidade,email,telefone)
VALUES
('Andr� Carrilo', 'Marteking Cultural', 'Carrilo@gmail.com',1198765421),
('Gustavo Henrique', 'Produ��o de Eventos', 'G.Henrique@gmail.com',1195765571),
('Rodrigo Garro', 'Artes Visuais', 'Garrito@gmail.com',1140028922),
('Yuri Alberto', 'Teatro', 'Protagonista@gmail.com',1191234567),
('Hugo Souza', 'M�sica', 'Hugo.S@gmail.com',1198765421),
('Matheus Franca', 'Cinema', 'Matheuzinho@gmail.com',1198576345),
('Breno Bidon', 'Literatura', 'Bidon@gmail.com',1198509743),
('Jos� Martinez', 'Fotogr�fia', 'Jose.ferias@gmail.com',1198764125),
('Roger Guedes', 'Organizador de Eventos', 'Roger.calvo@gmail.com',1199438267),
('Kaio C�sar', 'Patrim�nio Cultural', 'KaioCesar@gmail.com',1196767679);