SELECT * FROM Eventos;
SELECT * FROM Palestrantes;
SELECT * FROM Inscri��es
