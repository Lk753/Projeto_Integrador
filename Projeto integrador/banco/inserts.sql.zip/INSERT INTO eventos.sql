INSERT INTO Eventos (nome_evento,data_evento,local_evento,capacidade)
VALUES
('Festival de Musica', '20260624', 'Mirassol', 550),
('Show de Talentos', '20260702', 'Barretos', 250),
('Palestra sobre Cultura Indigena', '20260705', 'Ribeir�o Preto', 500),
('Mostra de Cinema Itinerante', '20260802', 'Uberl�ndia', 400),
('Apresenta��o de Teatro de Rua', '20260805', 'Campinas', 600),
('Festival de Cultura Urbana', '20260811', 'Guarulhos', 1200),
('Encontro de Folclore e Tradi��es', '20260814', 'Sumar�', 350),
('Oficina de Literatura e Poesia', '20260818', 'Bertioga', 180),
('Exposi��o de Artes', '20260822', 'Trememb�', 300),
('Concerto de M�sica Cl�ssica', '20260825', 'Limeira', 850);