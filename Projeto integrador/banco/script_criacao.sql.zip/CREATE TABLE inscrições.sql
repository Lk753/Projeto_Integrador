CREATE TABLE Inscri��es(
	id_incricao INT PRIMARY KEY IDENTITY(1,1),
	nome_participante VARCHAR(100),
	especialidade VARCHAR(100),
	email VARCHAR(100),
	telefone VARCHAR(20)
);