CREATE DATABASE DB_EventosCulturais;

