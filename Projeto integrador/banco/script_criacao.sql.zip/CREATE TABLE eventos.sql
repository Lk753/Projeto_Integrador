CREATE TABLE Eventos(
	id_evento INT PRIMARY KEY IDENTITY (1,1),
	nome_evento VARCHAR(100),
	data_evento DATE,
	local_evento VARCHAR(100),
	capacidade INT
);