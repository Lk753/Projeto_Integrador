CREATE TABLE Palestrantes(
	id_palestrante INT PRIMARY KEY IDENTITY(1,1),
	nome VARCHAR(100),
	especialidade VARCHAR(100),
	email VARCHAR(100),
	telefone VARCHAR(20)
);